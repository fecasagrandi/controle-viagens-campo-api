from django.shortcuts import render
from .core.models import Usuario, Destino, Transporte, Categoria, Viagem

# Create your views here.
